//
//  ViewController.swift
//  LLoader
//
//  Created by Alfredo Uzumaki on 2/28/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var smallLoader: LLoader!
    @IBOutlet weak var bigLoader: LLoader!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        // Start Loader
        smallLoader.isAnimating = true
        bigLoader.isAnimating = true
        
        creaeLoaderProgrammatically()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            // Stop Loader
            self.bigLoader.isAnimating = false
        }
    }
    
    func creaeLoaderProgrammatically() {
        let loader = LLoader(frame: smallLoader.frame)
        loader.layer.position.y = bigLoader.center.y + 150
        loader.layer.position.x = bigLoader.center.x - (loader.frame.width / 2)
        view.addSubview(loader)
        loader.isAnimating = true
    }
}

